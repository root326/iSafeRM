class BenchException(Exception):
    pass