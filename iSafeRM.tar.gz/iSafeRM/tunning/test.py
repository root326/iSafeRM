from utils import load_dict
res = load_dict("/home/lilong/iSafeRM/output/config")
print(res)